# Rusty Cup: chat push notifications and app-icon badges

The code is prepared, but push is **not live yet**. It needs the Firebase deployment and public web-push key below. Merely replacing the HTML file will not activate it.

This package preserves the existing game scoring, MVP, PDF summary, and Chat-tab unread badge. Chat notifications use a generic “New chat message” alert. They do not show the message text on the lock screen.

## What players will do

1. Add Rusty Cup to the iPhone Home Screen, if it is not already installed.
2. Open that Home Screen icon and sign in to their league account.
3. Open **Chat → Chat notifications → Enable push notifications** and tap **Allow**.

The installed app can receive alerts while closed. Tapping an alert opens chat. The app-icon number counts unread incoming chat messages since that device enabled push. Opening chat clears the icon badge. Each phone must enable notifications individually. Device notification settings can disable alerts or badges.

## Before activation

- Use the existing Firebase project **rusty-cup-34753**. Do not create a replacement project.
- This Firebase Cloud Functions implementation requires **Blaze**, with a linked billing account. It uses Firestore, Functions, Cloud Build/Artifact Registry and Firebase Cloud Messaging. Free allowances do not guarantee a zero bill. Upgrading or deploying is your action; this package changes no billing settings.
- Use a computer with Node.js 22 for the deployment commands, or a terminal environment with Node.js 22 and the Firebase CLI.
- The app URL is configured as https://peteloosbrock-cloud.github.io/Rusty-Cup/Rusty-Cup.html. The temporary v=110 query is omitted; notification links add chat=1.
- Check the privacy of the new Firebase collections before deployment, as described below.

## 1. Public web-push key: configured

Your Firebase public web-push key is already in `github/rusty-cup-push-config.js`. No key editing is needed. Keep this file alongside the app HTML when uploading to GitHub.

The trusted app URL is already in `firebase/functions/.env.rusty-cup-34753`: https://peteloosbrock-cloud.github.io/Rusty-Cup/Rusty-Cup.html.

If Firebase reports that the FCM Registration API or Cloud Messaging API is disabled, enable that API for this same Firebase project.

## 2. Keep push registrations private

The backend uses a new top-level collection, `rustycupPushDevices`, and nested delivery receipts. Only the Firebase Admin SDK in Cloud Functions needs access. Browser clients use authenticated callable functions instead of writing these documents directly.

The existing Firestore rules must deny all client access to this collection. The supplied `firebase/push-rules-fragment.txt` shows the matching rule. Add it **inside** your existing `/databases/{database}/documents` block while retaining all Rusty Cup rules. It is a fragment, not a replacement rules document.

An explicit deny does not override a different matching rule that allows access. If your rules have a broad catch-all that allows signed-in users to read or write every document, that rule must be tightened first. If unsure, share the current rules for review before deploying.

The package intentionally does not include a complete `firestore.rules` file or a Firestore deployment command, so it cannot overwrite your existing league rules.

## 3. Deploy the Firebase sender

These are terminal commands, not code to paste into GitHub or Firebase's Rules editor.

From the extracted package's `firebase/functions` folder:

```bash
npm install
```

Then move to its parent `firebase` folder:

```bash
cd ..
npx firebase-tools@latest login
npx firebase-tools@latest deploy --project rusty-cup-34753 --only functions:rustycup-push
```

The included `functions/.env.rusty-cup-34753` already sets `RUSTY_CUP_APP_URL` to your existing app: https://peteloosbrock-cloud.github.io/Rusty-Cup/Rusty-Cup.html. This sets the trusted site and notification-click destination. If the CLI still asks, enter that same URL.

The dedicated `rustycup-push` codebase keeps these functions separate from any existing Firebase functions. Approve required Google Cloud APIs in the deployment flow if you intend to proceed. The functions use Firebase-managed credentials; no service-account key belongs in GitHub.

## 4. Upload the website files

Upload these four files from `github` into the **same folder** that currently contains your Rusty Cup app:

- `Rusty-Cup.html`: replace your existing app file, **keeping its existing GitHub filename**. For example, if it is currently `index.html`, the new HTML must replace `index.html`.
- `rusty-cup-push-config.js`: use the copy containing your public web-push key.
- `rusty-cup-sw.js`: keep this exact filename, alongside the app HTML.
- `rusty-cup-notification-icon.png`: keep this exact filename.

Keep all existing icons and other website files. Do not upload the Firebase backend folder, `node_modules`, or Firebase credentials to your website. The service worker deliberately does not cache the app HTML, so it will not pin users to an old app version.

## 5. Verify on two accounts

1. On phone A, open the installed Rusty Cup app, sign in, and enable notifications in Chat.
2. Leave Chat, then close/background the installed app.
3. From account B, send a new league message.
4. Phone A should show an alert and an icon badge of 1. A second incoming message should make the badge 2.
5. Tap the alert, or open the icon and Chat. The badge should clear.
6. A message sent by account A must not notify account A's devices.
7. In **Chat → Chat notifications → Turn off**, disable and verify new alerts stop on that phone.

If permission was denied, use the phone's notification settings for Rusty Cup to allow it. A successful code upload alone does not establish delivery; complete this device test after deployment.

## Behavior and limits

- Permission and Home Screen installation are required on iPhone. OS notification settings, Focus modes, network conditions, and browser support govern delivery and badge display.
- Signing out removes this device's delivery token. Enable notifications again after switching accounts. Removing a league member also stops future sender delivery to that member's registered devices.
- Chat-tab read tracking remains local to each account/device. Push badges count unread messages queued for each enrolled device, so a newly enrolled device does not notify about old chat history.
- Pending/read IDs and deduplication history are bounded to 1,000 recent messages per device. Deleted chat messages reconcile the icon count when the app next opens; deleting a message does not send a new alert solely to change the badge.
- Notification tags and delivery receipts reduce duplicates. Push delivery is best effort, and a rare duplicate remains possible if the push service accepts a send just before a server retry.
- Receipts include an `expiresAt` timestamp. You may configure Firestore TTL for the `deliveries` collection group to clean them up after seven days; until TTL is enabled, they are retained.

## Validation completed here

Local simulated tests covered authenticated enrollment, ownership checks, membership removal, sender exclusion, unread counts, timestamp-based reading, trigger retry/deduplication, older background revisions, account isolation, foreground alerts and chat links, permission errors, and token removal. Existing scoring, PDF, MVP and Chat-tab badge checks also passed. This package has not been deployed to your Firebase account or verified on a physical phone.

## Official references

- [Apple/WebKit: Home Screen web push and badges](https://webkit.org/blog/13878/web-push-for-web-apps-on-ios-and-ipados/)
- [Firebase: Web Cloud Messaging setup](https://firebase.google.com/docs/cloud-messaging/web/get-started)
- [Firebase: Receive web messages](https://firebase.google.com/docs/cloud-messaging/web/receive-messages)
- [Firebase: Cloud Functions setup and Blaze requirement](https://firebase.google.com/docs/functions/get-started)
- [Firebase pricing](https://firebase.google.com/pricing)
