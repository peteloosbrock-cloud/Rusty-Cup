'use strict';
const {onCall,HttpsError}=require('firebase-functions/v2/https');
const {onDocumentCreated,onDocumentDeleted}=require('firebase-functions/v2/firestore');
const {defineString}=require('firebase-functions/params');
const {initializeApp}=require('firebase-admin/app');
const {getFirestore,FieldValue}=require('firebase-admin/firestore');
const {getMessaging}=require('firebase-admin/messaging');
const {createHash}=require('node:crypto');
initializeApp();
const db=getFirestore(),region='us-central1';
const appURL=defineString('RUSTY_CUP_APP_URL',{description:'Full HTTPS address of the existing Rusty Cup app (including its HTML filename if present)'});
const owner='5Mpcrs5zS8UyCXC66Udo83B1E5P2';
// These collections must remain inaccessible to browser clients. Admin SDK only.
const devices=db.collection('rustycupPushDevices');
const uidOf=request=>{if(!request.auth)throw new HttpsError('unauthenticated','Sign in first.');return request.auth.uid};
const eligible=async uid=>uid===owner||(await db.doc('rustycup/league/members/'+uid).get()).exists;
const idFor=token=>createHash('sha256').update(token).digest('hex');
const fail=message=>{throw new HttpsError('invalid-argument',message)};
const idsFrom=values=>{if(!Array.isArray(values)||values.length>100||values.some(id=>typeof id!=='string'||id.length>150))fail('Invalid message list.');return values};
const tail=ids=>[...new Set(ids)].slice(-1000);
const timeKey=t=>t&&Number.isInteger(t.seconds)?String(t.seconds).padStart(12,'0')+'.'+String(t.nanoseconds||0).padStart(9,'0'):'';
function trustedAppURL(){const url=new URL(appURL.value());if(url.protocol!=='https:'||url.username||url.password)throw Error('Configure an HTTPS app URL.');url.hash='';return url}
async function requireMember(request){const uid=uidOf(request);if(!await eligible(uid))throw new HttpsError('permission-denied','League membership is required.');return uid}
function deviceRef(request){const id=request.data?.deviceId;if(typeof id!=='string'||!/^[a-f0-9]{64}$/.test(id))fail('Invalid device.');return devices.doc(id)}
function badgeState(id,d){return {deviceId:id,revision:d.revision||0,unreadCount:(d.unreadIds||[]).length}}
exports.rustyCupRegisterPush=onCall({region,maxInstances:3},async request=>{
 const uid=await requireMember(request),token=request.data?.token;
 if(typeof token!=='string'||token.length<30||token.length>4096)fail('Invalid push registration.');
 const url=trustedAppURL(),origin=request.rawRequest?.headers?.origin;
 if(origin&&origin!==url.origin)throw new HttpsError('permission-denied','Open the configured Rusty Cup website.');
 const ref=devices.doc(idFor(token));
 return db.runTransaction(async tx=>{
  const snap=await tx.get(ref),old=snap.exists?snap.data():null;
  if(old&&old.uid!==uid)throw new HttpsError('permission-denied','Disable notifications on this device and enable them again under this account.');
  const d=old||{uid,token,unreadIds:[],unreadTimes:{},seenIds:[],readIds:[],readThrough:'',revision:1};
  tx.set(ref,{...d,updatedAt:FieldValue.serverTimestamp()});return badgeState(ref.id,d);
 });
});
exports.rustyCupReadPush=onCall({region,maxInstances:3},async request=>{
 const uid=await requireMember(request),ref=deviceRef(request),read=idsFrom(request.data?.messageIds),through=request.data?.through||'';
 if(through&&!/^\d{12}\.\d{9}$/.test(through))fail('Invalid read timestamp.');
 return db.runTransaction(async tx=>{
  const snap=await tx.get(ref);if(!snap.exists)return null;const d=snap.data();if(d.uid!==uid)throw new HttpsError('permission-denied','Wrong account.');
  const readSet=new Set([...(d.readIds||[]),...read]),readThrough=through>(d.readThrough||'')?through:(d.readThrough||''),unreadIds=(d.unreadIds||[]).filter(id=>!readSet.has(id)&&!(d.unreadTimes?.[id]&&d.unreadTimes[id]<=readThrough));
  const changed=unreadIds.length!==(d.unreadIds||[]).length||read.some(id=>!(d.readIds||[]).includes(id))||readThrough!==(d.readThrough||'');
  const next={...d,unreadIds,unreadTimes:Object.fromEntries(unreadIds.map(id=>[id,d.unreadTimes?.[id]||''])),readThrough,readIds:tail([...readSet]),revision:(d.revision||0)+(changed?1:0)};
  if(changed)tx.update(ref,{unreadIds:next.unreadIds,readIds:next.readIds,readThrough:next.readThrough,unreadTimes:next.unreadTimes,revision:next.revision});return badgeState(ref.id,next);
 });
});
exports.rustyCupDisablePush=onCall({region,maxInstances:3},async request=>{
 const uid=uidOf(request),ref=deviceRef(request);
 await db.runTransaction(async tx=>{const snap=await tx.get(ref);if(snap.exists&&snap.data().uid!==uid)throw new HttpsError('permission-denied','Wrong account.');tx.delete(ref)});return {disabled:true};
});
async function deliver(ref,messageId,message){
 const delivery=ref.collection('deliveries').doc(messageId);
 const queued=await db.runTransaction(async tx=>{
  const [deviceSnap,deliverySnap]=await Promise.all([tx.get(ref),tx.get(delivery)]);
  if(!deviceSnap.exists)return null;const d=deviceSnap.data();
  if(deliverySnap.exists&&deliverySnap.data().done)return null;
  if((d.readIds||[]).includes(messageId)||(timeKey(message.createdAt)&&timeKey(message.createdAt)<=(d.readThrough||''))){tx.set(delivery,{done:true,expiresAt:new Date(Date.now()+7*86400000)});return null}
  const seen=(d.seenIds||[]).includes(messageId),next={...d,unreadIds:tail([...(d.unreadIds||[]),messageId]),seenIds:tail([...(d.seenIds||[]),messageId]),revision:(d.revision||0)+(seen?0:1)};
  if(!seen)tx.update(ref,{unreadIds:next.unreadIds,unreadTimes:{...Object.fromEntries(next.unreadIds.map(id=>[id,d.unreadTimes?.[id]||''])),[messageId]:timeKey(message.createdAt)},seenIds:next.seenIds,revision:next.revision});
  return {...badgeState(ref.id,next),token:d.token};
 });
 if(!queued)return;
 const url=trustedAppURL();url.searchParams.set('chat','1');
 const icon=new URL('./rusty-cup-notification-icon.png',url).href;
 try{
  await getMessaging().send({token:queued.token,notification:{title:'Rusty Cup · New chat message',body:'Open Rusty Cup to read the league chat.'},data:{kind:'rustycup-chat',messageId,deviceId:ref.id,revision:String(queued.revision),unreadCount:String(queued.unreadCount)},webpush:{headers:{TTL:'86400'},notification:{icon,tag:'rustycup-chat-'+messageId},fcmOptions:{link:url.href}}});
  await delivery.set({done:true,expiresAt:new Date(Date.now()+7*86400000)});
 }catch(error){
  if(['messaging/registration-token-not-registered','messaging/invalid-registration-token'].includes(error.code)){await ref.delete();return}
  throw error;
 }
}
exports.rustyCupChatCreated=onDocumentCreated({document:'rustycup/league/messages/{messageId}',region,retry:true,maxInstances:3},async event=>{
 const message=event.data?.data();if(!message||typeof message.uid!=='string')return;
 // Never notify people who have been removed, or the person sending the message.
 const all=await devices.get(),membership=new Map();
 for(const snap of all.docs){const d=snap.data();if(d.uid===message.uid)continue;
  if(!membership.has(d.uid))membership.set(d.uid,await eligible(d.uid));
  if(!membership.get(d.uid)){await snap.ref.delete();continue}
  await deliver(snap.ref,event.params.messageId,message);
 }
});
exports.rustyCupChatDeleted=onDocumentDeleted({document:'rustycup/league/messages/{messageId}',region,retry:true,maxInstances:3},async event=>{
 const all=await devices.get();
 for(const snap of all.docs)await db.runTransaction(async tx=>{const latest=await tx.get(snap.ref);if(!latest.exists)return;const d=latest.data(),unreadIds=(d.unreadIds||[]).filter(id=>id!==event.params.messageId);if(unreadIds.length!==(d.unreadIds||[]).length)tx.update(snap.ref,{unreadIds,revision:(d.revision||0)+1})});
 // The icon reconciles to the exact remaining unread count when the app next opens.
});
